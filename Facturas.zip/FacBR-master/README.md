# FacBR

Proyecto de implementación de búsqueda de facturas por ID y muestra de información

Créditos:
Brian Rivera
Rudy Sanchez
